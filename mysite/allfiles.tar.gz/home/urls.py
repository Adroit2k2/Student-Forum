from django.urls import path
from django.contrib import admin
from . import views
from django.contrib.auth import views as auth_views

from home.views import signup_view
app_name='home'

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.HomeView.as_view(),name='home'),
    path('home/', views.ContentView.as_view(),name='content'),
    path('signup/', signup_view,name='signup'),
]

from django.shortcuts import render, redirect, get_object_or_404
from django.views import View
import requests
import json
from .services import *

def search(View):
    return render(View, 'books/search.html')


def api(request):
    # query = request.GET
    if request.method == 'POST':
        name = request.POST['name']
    googleapikey="AIzaSyC-mr7EoTkI8_XLAVuMEY2L61Fho9EKJaI"
    params={'q': name,'key': googleapikey}
    google_books = requests.get(url="https://www.googleapis.com/books/v1/volumes/", params=params)
    books_json = google_books.json()
    bookshelf = books_json["items"]
    arr=[]
    try:
        for book in bookshelf:
            d={"selflink":book["selfLink"],"link":book["accessInfo"]["webReaderLink"],"name":book["volumeInfo"]["title"],"imagelink":book["volumeInfo"]["imageLinks"]["thumbnail"],'authors':book['volumeInfo']['authors'],"description":book['volumeInfo']['description']}
            if book["volumeInfo"]["industryIdentifiers"][0]["type"] == 'ISBN_13':
                d["ISBN13"] = book["volumeInfo"]["industryIdentifiers"][0]["identifier"]
                d["ISBN10"] = book["volumeInfo"]["industryIdentifiers"][1]["identifier"]
            elif book["volumeInfo"]["industryIdentifiers"][0]["type"] == 'ISBN_10':
                d["ISBN10"] = book["volumeInfo"]["industryIdentifiers"][0]["identifier"]
                d["ISBN13"] = book["volumeInfo"]["industryIdentifiers"][1]["identifier"]
            arr.append(d)
    except:
        pass
    return render(request, 'books/api.html', {'books':bookshelf,'bookshelf':arr,'abc':bookshelf})
    #return render(request, 'books/api.html', response)

def book(request):
    if request.method == 'POST':
        isbn = request.POST['isbn']

    return render(request,'books/api_test.html',{'isbn':isbn})